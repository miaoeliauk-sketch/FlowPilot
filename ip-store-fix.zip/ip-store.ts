"use client";
import { IPProfile, StyleProfile, AIMemory } from "./types";

const KEY_IPS = "ipwr:ips";
const KEY_ACTIVE_IP = "ipwr:activeIpId";
const KEY_STYLE = "ipwr:styleProfiles";
const KEY_MEMORY = "ipwr:aiMemories";

function readJSON<T>(key: string, fallback: T): T {
  if (typeof window === "undefined") return fallback;
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch { return fallback; }
}

function writeJSON<T>(key: string, value: T) {
  if (typeof window === "undefined") return;
  try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* ignore quota errors */ }
}

const COLORS = ["#7C6EE6", "#5BA4D6", "#E66E8E", "#5BC192", "#C99A1E", "#9B7ED9"];

function genId() { return `${Date.now()}-${Math.random().toString(36).slice(2,8)}`; }

// ── IP 默认种子数据（首次使用时填充，方便用户立刻看到效果） ──
function seedDefaultIPs(): IPProfile[] {
  const now = new Date().toISOString();
  return [
    {
      id: genId(), name: "喂鱼", avatar: "喂",
      positioning: "AI+IP自媒体，专注AI工具与效率工作流分享",
      platforms: ["抖音", "视频号", "小红书", "B站"],
      audience: "AI+IP内容创作者、自媒体从业者",
      bio: "专注AI工具教学和内容创作方法论的自媒体账号",
      color: COLORS[0], createdAt: now, updatedAt: now,
    },
  ];
}

// ── IP CRUD ──
export function getAllIPs(): IPProfile[] {
  const ips = readJSON<IPProfile[]>(KEY_IPS, []);
  if (ips.length === 0) {
    const seeded = seedDefaultIPs();
    writeJSON(KEY_IPS, seeded);
    return seeded;
  }
  return ips;
}

export function getIP(id: string): IPProfile | null {
  return getAllIPs().find(ip => ip.id === id) ?? null;
}

export function createIP(input: Omit<IPProfile, "id"|"createdAt"|"updatedAt"|"color">): IPProfile {
  const ips = getAllIPs();
  const now = new Date().toISOString();
  const newIP: IPProfile = {
    ...input, id: genId(), color: COLORS[ips.length % COLORS.length],
    createdAt: now, updatedAt: now,
  };
  writeJSON(KEY_IPS, [...ips, newIP]);
  return newIP;
}

export function updateIP(id: string, patch: Partial<IPProfile>): void {
  const ips = getAllIPs().map(ip => ip.id === id ? { ...ip, ...patch, updatedAt: new Date().toISOString() } : ip);
  writeJSON(KEY_IPS, ips);
}

export function deleteIP(id: string): void {
  const ips = getAllIPs().filter(ip => ip.id !== id);
  writeJSON(KEY_IPS, ips);
  if (getActiveIPId() === id) {
    setActiveIPId(ips[0]?.id ?? null);
  }
}

// ── 当前激活 IP ──
export function getActiveIPId(): string | null {
  return readJSON<string | null>(KEY_ACTIVE_IP, null);
}

export function setActiveIPId(id: string | null): void {
  writeJSON(KEY_ACTIVE_IP, id);
}

export function getOrInitActiveIP(): IPProfile {
  const ips = getAllIPs();
  const activeId = getActiveIPId();
  const found = ips.find(ip => ip.id === activeId);
  if (found) return found;
  // 没有激活IP，默认选第一个
  setActiveIPId(ips[0].id);
  return ips[0];
}

// ── 风格档案 ──
export function getStyleProfile(ipId: string): StyleProfile | null {
  const all = readJSON<StyleProfile[]>(KEY_STYLE, []);
  return all.find(s => s.ipId === ipId) ?? null;
}

export function saveStyleProfile(profile: StyleProfile): void {
  const all = readJSON<StyleProfile[]>(KEY_STYLE, []);
  const idx = all.findIndex(s => s.ipId === profile.ipId);
  if (idx >= 0) all[idx] = profile; else all.push(profile);
  writeJSON(KEY_STYLE, all);
}

export function getOrCreateStyleProfile(ipId: string): StyleProfile {
  const existing = getStyleProfile(ipId);
  if (existing) return existing;
  const fresh: StyleProfile = {
    id: genId(), ipId, tone: "", commonOpenings: [], commonClosings: [],
    catchphrases: [], forbiddenExpressions: [], trainingSourceIds: [], lastTrainedAt: null,
  };
  saveStyleProfile(fresh);
  return fresh;
}

// ── AI 记忆库 ──
export function getAIMemory(ipId: string): AIMemory {
  const all = readJSON<AIMemory[]>(KEY_MEMORY, []);
  return all.find(m => m.ipId === ipId) ?? {
    ipId, topicPatterns: [], audienceInsights: [], successPatterns: [], lastUpdatedAt: null,
  };
}

export function updateAIMemory(ipId: string, patch: Partial<AIMemory>): void {
  const all = readJSON<AIMemory[]>(KEY_MEMORY, []);
  const idx = all.findIndex(m => m.ipId === ipId);
  const current = idx >= 0 ? all[idx] : getAIMemory(ipId);
  const updated: AIMemory = { ...current, ...patch, lastUpdatedAt: new Date().toISOString() };
  if (idx >= 0) all[idx] = updated; else all.push(updated);
  writeJSON(KEY_MEMORY, all);
}
